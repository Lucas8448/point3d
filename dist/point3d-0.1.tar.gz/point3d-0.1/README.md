# point3d
A pypi package for converting 3d points to 2d pixel coordinates
